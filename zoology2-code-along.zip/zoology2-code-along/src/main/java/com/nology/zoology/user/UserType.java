package com.nology.zoology.user;

public enum UserType {

    zooKeeper, visitor;

}
