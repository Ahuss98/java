package com.nology.zoology.command;

public enum CommandType {

    visitor;

}
