package com.nology.zoology.animal;

public enum AnimalSorting {

    byId, byName, byType;

}
