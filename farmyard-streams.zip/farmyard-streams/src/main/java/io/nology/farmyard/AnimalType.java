package io.nology.farmyard;

public enum AnimalType {

    dog, cat, cow, horse, chicken, duck;

}
