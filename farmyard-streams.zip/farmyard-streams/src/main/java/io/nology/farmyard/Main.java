package io.nology.farmyard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    private static FarmYard farmYard = new FarmYard();

    public static void main(String[] args) {

    }

}
