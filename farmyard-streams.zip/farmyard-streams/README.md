# farmyard-streams
Streams and farmyard

Playing around with **Streams** using a bunch for farm animals.

Look at `io/nology/farmyard/Main.java` for details.
